import streamlit as st
import pandas as pd
import re
import nltk

from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB

# Page Configuration
st.set_page_config(
    page_title="AI Spam Mail Detector",
    page_icon="🚨",
    layout="centered"
)

# Custom Styling
st.markdown("""
<style>

.stApp {
    background-color: black;
}s

h1, h2, h3, p, label, div {
    color: red !important;
}

.stTextArea textarea {
    background-color: #111111 !important;
    color: red !important;
    border: 2px solid red !important;
    border-radius: 10px;
}

.stButton button {
    background-color: red !important;
    color: black !important;
    font-weight: bold;
    border-radius: 10px;
    width: 100%;
}

.stButton button:hover {
    background-color: darkred !important;
    color: white !important;
}

</style>
""", unsafe_allow_html=True)

# Download stopwords
nltk.download('stopwords')

# Load Dataset
data = pd.read_csv(
    "SMSSpamCollection",
    sep="\t",
    header=None,
    names=["label", "message"]
)

# Stopwords
stop_words = set(stopwords.words('english'))

# Text Cleaning Function
def clean_text(text):

    text = text.lower()

    text = re.sub(r'[^a-zA-Z\s]', '', text)

    words = text.split()

    words = [word for word in words if word not in stop_words]

    return " ".join(words)

# Preprocessing
data['clean_message'] = data['message'].apply(clean_text)

data['label_num'] = data['label'].map({
    'ham': 0,
    'spam': 1
})

# TF-IDF
tfidf = TfidfVectorizer()

X = tfidf.fit_transform(data['clean_message'])

y = data['label_num']

# Train/Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Train Model
model = MultinomialNB()

model.fit(X_train, y_train)

# Title
st.title("🚨 AI Spam Mail Detector")

st.write(
    "This AI model uses the SMS Spam Collection Dataset to classify messages as Spam or Ham."
)

# Input Box
message = st.text_area(
    "Enter Message",
    placeholder="Type your message here..."
)

# Predict Button
if st.button("Predict Message"):

    if message.strip() == "":
        st.warning("Please enter a message.")
    else:

        cleaned = clean_text(message)

        vector = tfidf.transform([cleaned])

        prediction = model.predict(vector)

        if prediction[0] == 1:

            st.error("🚨 SPAM MESSAGE DETECTED")

        else:

            st.success("✅ HAM MESSAGE")