import pandas as pd
import re
import nltk
import matplotlib.pyplot as plt

from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import ConfusionMatrixDisplay

# Download stopwords
nltk.download('stopwords')

# Load dataset
data = pd.read_csv(
    "SMSSpamCollection",
    sep="\t",
    header=None,
    names=["label", "message"]
)

# Stopwords
stop_words = set(stopwords.words('english'))

# Clean text
def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^a-zA-Z\s]', '', text)

    words = text.split()
    words = [word for word in words if word not in stop_words]

    return " ".join(words)

# Apply cleaning
data['clean_message'] = data['message'].apply(clean_text)

# Convert labels
data['label_num'] = data['label'].map({
    'ham': 0,
    'spam': 1
})

# TF-IDF
tfidf = TfidfVectorizer()

X = tfidf.fit_transform(data['clean_message'])
y = data['label_num']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Train model
model = MultinomialNB()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# ==========================
# GRAPH 1 : SPAM VS HAM
# ==========================

spam_ham = data['label'].value_counts()

plt.figure(figsize=(6,4))
spam_ham.plot(kind='bar')

plt.title("Spam vs Ham Messages")
plt.xlabel("Message Type")
plt.ylabel("Count")

plt.show()

# ==========================
# GRAPH 2 : CONFUSION MATRIX
# ==========================

ConfusionMatrixDisplay.from_predictions(y_test, y_pred)

plt.title("Spam Detection Confusion Matrix")

plt.show()